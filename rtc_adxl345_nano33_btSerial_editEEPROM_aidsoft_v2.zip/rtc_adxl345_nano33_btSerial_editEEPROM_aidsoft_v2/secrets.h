// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "SSID"		// replace MySSID with your WiFi network name
#define SECRET_PASS "PASSWORD"	// replace MyPassword with your WiFi password

#define SECRET_WRITE_APIKEY "88BCDBBD8D36F218CDA5D552B31CC4"   // replace XYZ with your channel write API Key
